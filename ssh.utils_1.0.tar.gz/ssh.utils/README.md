ssh.utils
=========

R package with utilities for local and remote command execution (un*x only).
