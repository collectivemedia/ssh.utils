ssh.utils
=========

R package with utilities for local and remote command execution (un*x only). See http://collectivemedia.github.io/ssh.utils/ for more detail.
